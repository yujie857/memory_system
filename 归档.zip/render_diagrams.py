# Render memory-system design diagrams to PNG (2x DPI).
# Outputs: architecture.png, data-partition.png, er-model.png, write-pipeline.png
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, Rectangle

plt.rcParams["font.family"] = ["PingFang SC", "Hiragino Sans GB", "sans-serif"]
plt.rcParams["axes.unicode_minus"] = False

C_ARROW = "#64748b"
C_DASH = "#94a3b8"
INK = "#312e81"          # platform indigo
AMBER_T, AMBER_I = "#b45309", "#78350f"
TEAL_T, TEAL_I = "#0f766e", "#134e4a"
PURP_T, PURP_I = "#7e22ce", "#581c87"
GREEN_T = "#166534"


def make_canvas(w, h):
    fig = plt.figure(figsize=(w / 100, h / 100), dpi=100)
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set_xlim(0, w)
    ax.set_ylim(h, 0)
    ax.axis("off")
    ax.add_patch(Rectangle((0, 0), w, h, facecolor="#f8fafc", edgecolor="none", zorder=0))
    return fig, ax


def box(ax, x, y, w, h, fc, ec, dashed=False, shadow=False, lw=1.2, r=10, z=2):
    style = f"round,pad=0,rounding_size={r}"
    ls = (0, (6, 4)) if dashed else "solid"
    if shadow:
        ax.add_patch(FancyBboxPatch((x, y + 3), w, h, boxstyle=style,
                                    facecolor="#0f172a", edgecolor="none", alpha=0.06, zorder=z - 1))
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle=style,
                                facecolor=fc, edgecolor=ec, linewidth=lw, linestyle=ls, zorder=z))


def text(ax, x, y, s, size, color="#0f172a", weight="normal", ha="left", rotation=0):
    ax.text(x, y, s, fontsize=size, color=color, fontweight=weight,
            ha=ha, va="baseline", rotation=rotation, zorder=3)


def ctext(ax, x, y, s, size, color="#0f172a", weight="normal"):
    ax.text(x, y, s, fontsize=size, color=color, fontweight=weight,
            ha="center", va="center", zorder=3)


def arrow(ax, x1, y1, x2, y2, dashed=False, mutation=15):
    c = C_DASH if dashed else C_ARROW
    ls = (0, (6, 4)) if dashed else "solid"
    ax.annotate("", xy=(x2, y2), xytext=(x1, y1),
                arrowprops=dict(arrowstyle="-|>", mutation_scale=mutation, color=c,
                                lw=1.8, linestyle=ls, shrinkA=0, shrinkB=0), zorder=4)


def line(ax, pts, dashed=False, lw=1.6, color=None):
    c = color or (C_DASH if dashed else C_ARROW)
    ls = (0, (6, 4)) if dashed else "solid"
    ax.plot([p[0] for p in pts], [p[1] for p in pts], color=c, lw=lw,
            linestyle=ls, solid_capstyle="round", zorder=1.5)


def elbow(ax, pts, dashed=False):
    c = C_DASH if dashed else C_ARROW
    ls = (0, (6, 4)) if dashed else "solid"
    line(ax, pts, dashed=dashed)
    (x1, y1), (x2, y2) = pts[-2], pts[-1]
    ax.annotate("", xy=(x2, y2), xytext=(x1, y1),
                arrowprops=dict(arrowstyle="-|>", mutation_scale=15, color=c,
                                lw=1.8, linestyle=ls, shrinkA=0, shrinkB=0), zorder=4)


def field_box(ax, x, y, w, h, fc, ec, title, title_color, fields, field_color="#334155",
              title_size=12.5, field_size=9.5, pad=16, line_h=21, shadow=False):
    box(ax, x, y, w, h, fc, ec, shadow=shadow)
    text(ax, x + pad, y + 26, title, title_size, title_color, "bold")
    for i, f in enumerate(fields):
        text(ax, x + pad, y + 26 + (i + 1) * line_h, f, field_size, field_color)


# ================================================================ 1. architecture
fig, ax = make_canvas(1640, 1060)

ctext(ax, 800, 30, "销售 Agent 记忆系统 · 总体架构（V0.2）", 19, weight="bold")
ctext(ax, 800, 60, "读取路径（左）与写入管道（右）汇合于唯一存储服务；注入边界由双层守卫保证 personal 永不进入共享上下文", 11, "#64748b")

# ① 接入层
box(ax, 40, 90, 1520, 170, "#ffffff", "#e2e8f0", shadow=True)
text(ax, 64, 120, "① 接入层（项目空间实体：Conversation = member_private | shared）", 12, "#64748b", "bold")
for cx, top, bot in [(280, "成员 A · 个人会话（private）", "个人助手 A"),
                     (760, "成员 B · 个人会话（private）", "个人助手 B"),
                     (1240, "项目 · 共享会话（shared）", "共享会话 Agent")]:
    box(ax, cx - 180, 132, 360, 42, "#eef2ff", "#c7d2fe")
    ctext(ax, cx, 158, top, 11.5, INK)
    arrow(ax, cx, 174, cx, 192)
    box(ax, cx - 180, 196, 360, 42, "#e0e7ff", "#c7d2fe")
    ctext(ax, cx, 222, bot, 12, INK)
    arrow(ax, cx, 238, cx, 284)

# ② 上下文组装器
box(ax, 40, 290, 1520, 150, "#f5f3ff", "#ddd6fe", shadow=True)
text(ax, 64, 320, "② 上下文组装器 · 注入规则引擎", 12, "#6d28d9", "bold")
text(ax, 88, 350, "组装算法：置顶 → 近期(14d, fact/need/intel) → 未结 commitment → 主题召回(topK=3, sim≥0.78) → 预算裁剪 ≤600 token", 11.5, "#4c1d95")
text(ax, 88, 380, "注入规则：private 会话 = 本人 personal + 本项目 project；shared 会话 = 仅 project（守卫①：scope 白名单强制）", 11.5, "#4c1d95")
text(ax, 88, 408, "渲染：按 personal / project 分组，条目带 [作者 · 日期 · 类型] 标签，可回链来源消息", 10.5, "#475569")
text(ax, 88, 429, "会话内更多细节：Agent 主动调用 memory_search / memory_remember / memory_correct / memory_pin", 10.5, "#475569")

arrow(ax, 350, 440, 350, 474)
elbow(ax, [(1560, 175), (1600, 175), (1600, 500), (1586, 500)])
text(ax, 1610, 390, "会话数据 · 显式触发", 9.5, "#64748b", ha="center", rotation=-90)

# Retriever
box(ax, 60, 480, 580, 200, "#f0fdfa", "#5eead4", shadow=True)
ctext(ax, 350, 502, "Memory Retriever · 读取服务", 13, TEAL_T, "bold")
text(ax, 92, 534, "① Scope 硬过滤：personal 仅 owner；project 限项目成员", 11.5, TEAL_I)
text(ax, 92, 562, "② 混合召回：BM25 + 向量 → RRF 融合 → rerank", 11.5, TEAL_I)
text(ax, 92, 590, "③ 过滤 status / expiry，返回条目 + 来源引用", 11.5, TEAL_I)
text(ax, 92, 618, "守卫②：存储层再校验 operatorId == owner_id，违规拒答", 9.5, TEAL_T)
text(ax, 92, 642, "（返回附 conversationId / messageId 溯源）", 9.5, "#64748b")

# 写入管道
box(ax, 1000, 480, 580, 200, "#fffbeb", "#fcd34d", shadow=True)
ctext(ax, 1290, 502, "写入管道 · 萃取 → 判重/冲突 → 路由", 13, AMBER_T, "bold")
text(ax, 1032, 534, "来源：会话结束/每 8 轮 · “记住…” · 手动编辑", 11.5, AMBER_I)
text(ax, 1032, 562, "萃取器（六类模板+负例）→ Rule A–D 判重/冲突", 11.5, AMBER_I)
text(ax, 1032, 590, "路由决策表 → 确认卡片（保留/覆盖/并存）", 11.5, AMBER_I)
text(ax, 1032, 618, "低置信 → 会话末尾沉淀摘要，7 天未确认丢弃", 11.5, AMBER_I)
text(ax, 1032, 642, "覆盖他人条目 → 下次进入项目时通知原作者", 9.5, "#64748b")

elbow(ax, [(350, 680), (350, 704), (640, 704), (640, 716)])
elbow(ax, [(1290, 680), (1290, 704), (1000, 704), (1000, 716)])

# Store
box(ax, 430, 720, 780, 110, "#faf5ff", "#d8b4fe", shadow=True)
ctext(ax, 820, 752, "Memory Store · 全局唯一写入口", 13, PURP_T, "bold")
ctext(ax, 820, 784, "事务写入 · 承继链（supersede） · 修订历史 revisions · 审计 · 软删除", 11.5, PURP_I)

arrow(ax, 615, 832, 615, 874)
arrow(ax, 1025, 832, 1025, 874)

box(ax, 430, 880, 370, 110, "#f0fdf4", "#86efac", shadow=True)
ctext(ax, 615, 908, "关系库 · 唯一事实源", 12, GREEN_T, "bold")
ctext(ax, 615, 936, "entries / revisions / links", 10.5, "#475569")
ctext(ax, 615, 962, "Postgres + pgvector", 9.5, "#64748b")

box(ax, 840, 880, 370, 110, "#f0fdf4", "#86efac", shadow=True)
ctext(ax, 1025, 908, "向量索引 · 可重建派生", 12, GREEN_T, "bold")
ctext(ax, 1025, 936, "embedding(1024) + 原文", 10.5, "#475569")
ctext(ax, 1025, 962, "冗余 scope/project 预过滤", 9.5, "#64748b")

box(ax, 1290, 880, 300, 110, "#ffffff", "#94a3b8", dashed=True)
ctext(ax, 1440, 908, "V2 调度器 · 周期任务", 11, "#64748b", "bold")
ctext(ax, 1440, 936, "TTL 过期 · commitment 提醒", 10.5, "#475569")
ctext(ax, 1440, 962, "候选清理 · 归档复盘 → 通知", 10.5, "#475569")
elbow(ax, [(1440, 876), (1440, 800), (1216, 800)], dashed=True)

ctext(ax, 800, 1030, "org 组织层（产品资料 / 竞品库 / 复盘案例）为预留扩展位，V3 实现 —— 实体绑定详见 er-model.png，写入细节详见 write-pipeline.png", 9.5, "#64748b")

fig.savefig("memory-system-design/architecture.png", dpi=200, facecolor="#f8fafc")
plt.close(fig)

# ================================================================ 2. data partition
fig, ax = make_canvas(1240, 820)

ctext(ax, 620, 30, "数据逻辑分区 · 作用域视角", 19, weight="bold")
ctext(ax, 620, 60, "个人记忆跟随人，项目记忆跟随项目；org 层为预留扩展位", 11, "#64748b")

box(ax, 60, 100, 540, 560, "#f5f7ff", "#c7d2fe", shadow=True)
ctext(ax, 330, 128, "personal · 个人记忆", 13.5, "#3730a3", "bold")
ctext(ax, 330, 154, "ownerId 隔离 · 跨项目跟随人 · 仅本人可见", 10.5, "#475569")

box(ax, 92, 176, 476, 180, "#ffffff", "#c7d2fe")
text(ax, 116, 206, "member A 私有", 11.5, INK, "bold")
text(ax, 116, 234, "• 通用条目：工作偏好 / 话术沉淀 / 跨项目人脉", 10.5, "#334155")
text(ax, 116, 260, "• 来源标签：项目 P1、项目 P2 …（软回溯）", 10.5, "#334155")
text(ax, 116, 286, "• 检索规则：项目上下文内，本项目标签优先", 10.5, "#334155")
text(ax, 116, 320, "※ 任何对外共享都需显式“升格”动作", 9.5, "#64748b")

box(ax, 92, 376, 476, 110, "#ffffff", "#c7d2fe")
text(ax, 116, 406, "member B 私有", 11.5, INK, "bold")
text(ax, 116, 434, "• 与 A 完全隔离，结构相同", 10.5, "#334155")
text(ax, 116, 462, "成员数量不限，一人一区", 9.5, "#64748b")

text(ax, 92, 540, "管理界面：按项目标签筛选 · 编辑 · 删除 · 置顶 · 过期", 10.5, "#475569")
text(ax, 92, 568, "所有变更写入 memory_revisions（操作者 + 来源会话）", 9.5, "#64748b")

box(ax, 660, 100, 540, 560, "#f0fdfa", "#99f6e4", shadow=True)
ctext(ax, 930, 128, "project · 项目记忆", 13.5, TEAL_T, "bold")
ctext(ax, 930, 154, "projectId 隔离 · 项目内全体成员共享", 10.5, "#475569")

box(ax, 692, 176, 476, 240, "#ffffff", "#99f6e4")
text(ax, 716, 206, "项目 P1", 11.5, TEAL_I, "bold")
text(ax, 716, 234, "• fact 客户事实 · need 需求痛点 · intel 竞争情报", 10.5, "#334155")
text(ax, 716, 260, "• episode 互动记录 · preference 偏好", 10.5, "#334155")
text(ax, 716, 286, "• commitment 承诺 / 行动项（带 TTL）", 10.5, "#334155")
text(ax, 716, 312, "• lesson 经验沉淀（归档复盘产出）", 10.5, "#334155")
text(ax, 716, 346, "条目含作者与来源；编辑他人条目需作者 / 管理员权限", 9.5, "#64748b")
text(ax, 716, 372, "冲突更新：原作者收到通知，不静默覆盖", 9.5, "#64748b")

box(ax, 692, 436, 476, 70, "#ffffff", "#99f6e4")
text(ax, 716, 464, "项目 P2 …", 11.5, TEAL_I, "bold")
text(ax, 716, 490, "结构相同，按 projectId 硬隔离", 9.5, "#64748b")

text(ax, 692, 548, "成员退出：其条目保留在项目，不随人走", 10.5, "#475569")
text(ax, 692, 576, "项目归档：整体转只读，可查可追溯", 9.5, "#64748b")

arrow(ax, 600, 300, 654, 300)
ctext(ax, 627, 284, "升格（投稿 · 需确认）", 9.5, "#64748b")
arrow(ax, 930, 662, 930, 694, dashed=True)
text(ax, 945, 684, "归档复盘（V3）", 9.5, "#64748b")

box(ax, 60, 700, 1140, 80, "#ffffff", "#94a3b8", dashed=True)
ctext(ax, 630, 732, "org · 组织层（预留扩展位，V3 实现）", 11.5, "#64748b", "bold")
ctext(ax, 630, 758, "产品资料 / 竞品库 / 标准话术 / 赢输单复盘案例 —— scope 枚举预留，无需迁移存量数据", 10.5, "#475569")

fig.savefig("memory-system-design/data-partition.png", dpi=200, facecolor="#f8fafc")
plt.close(fig)

# ================================================================ 3. ER model
fig, ax = make_canvas(1500, 960)

ctext(ax, 750, 30, "项目空间实体 × 记忆系统绑定（ER 视角）", 19, weight="bold")
ctext(ax, 750, 58, "左侧为平台项目空间实体（假设模型，见 §14 校准项），右侧为记忆系统四张表；连线为绑定关系", 11, "#64748b")

# ---- 平台实体（靛蓝）
text(ax, 70, 96, "平台 · 项目空间（假设模型）", 12, "#64748b", "bold")
field_box(ax, 70, 150, 270, 100, "#eef2ff", "#c7d2fe", "User", INK,
          ["PK userId", "name · 平台角色"])
field_box(ax, 70, 320, 270, 120, "#eef2ff", "#c7d2fe", "Membership", INK,
          ["PK (userId, projectId)", "role: owner | member", "joinedAt"])
field_box(ax, 70, 510, 270, 130, "#eef2ff", "#c7d2fe", "Project（项目空间）", INK,
          ["PK projectId", "name · 客户", "status: active | archived", "createdBy"])
field_box(ax, 430, 150, 320, 140, "#eef2ff", "#c7d2fe", "Conversation", INK,
          ["PK conversationId · FK projectId", "type: member_private | shared", "participants[]"])
field_box(ax, 430, 330, 320, 120, "#eef2ff", "#c7d2fe", "Message", INK,
          ["PK messageId · FK conversationId", "authorId · ts"])
field_box(ax, 430, 515, 320, 120, "#eef2ff", "#c7d2fe", "Task（可选）", INK,
          ["PK taskId · FK projectId", "assigneeId · dueAt"])

# 平台内部关系
line(ax, [(205, 250), (205, 320)])
text(ax, 214, 292, "1──∞", 9.5, "#64748b")
line(ax, [(205, 440), (205, 510)])
text(ax, 214, 480, "1──∞", 9.5, "#64748b")
line(ax, [(270, 510), (270, 470), (400, 470), (400, 220), (430, 220)])
text(ax, 384, 350, "1──∞", 9.5, "#64748b", rotation=-90)
line(ax, [(340, 575), (430, 575)])
text(ax, 352, 566, "1──∞", 9.5, "#64748b")
line(ax, [(590, 290), (590, 330)])
text(ax, 600, 314, "1──∞", 9.5, "#64748b")

# ---- 记忆系统表
text(ax, 880, 96, "记忆系统（本项目）", 12, "#64748b", "bold")
field_box(ax, 880, 120, 550, 330, "#faf5ff", "#c084fc", "memory_entries（唯一事实源）", PURP_T,
          ["PK id = mem_<ULID>",
           "scope: personal | project（org 预留）",
           "project_id?（project 必填） · owner_id（作者/归属人）",
           "type: fact·need·intel·episode·preference·commitment·lesson",
           "text · structured(JSONB) · tags[]",
           "status: candidate|active|superseded|expired|archived|deleted",
           "superseded_by（承继链） · expires_at（TTL） · pinned",
           "source: { kind, conversationId, messageId, taskId? }",
           "confidence · created_by/at · updated_at",
           "CHECK (scope='project') = (project_id IS NOT NULL)"],
          field_size=9.5, line_h=27)
field_box(ax, 880, 510, 550, 140, "#f1f5f9", "#cbd5e1", "memory_revisions（审计全链）", "#475569",
          ["memory_id(FK) · actor(id, kind: user|agent|system)",
           "action: created|confirmed|rejected|edited|superseded|…",
           "before/after(JSON) · source（变更来源会话） · created_at"],
          field_size=9.5, line_h=26)
field_box(ax, 880, 710, 265, 120, "#f0fdf4", "#86efac", "memory_embeddings", GREEN_T,
          ["PK/FK memory_id", "vector(1024)", "冗余 scope/project 预过滤"], field_size=9, line_h=24)
field_box(ax, 1165, 710, 265, 120, "#f0fdf4", "#86efac", "memory_links", GREEN_T,
          ["PK (from_id, to_id, rel)", "rel: derived_from |", "duplicate_of | contradicts"], field_size=9, line_h=24)

# ---- 绑定关系
line(ax, [(340, 160), (340, 105), (880, 105), (880, 120)])
text(ax, 560, 98, "1────∞ owner_id（personal 归属）", 9.5, "#64748b")
line(ax, [(340, 575), (385, 575), (385, 478), (1000, 478), (1000, 450)])
text(ax, 660, 470, "1────∞ project_id（project 归属）", 9.5, "#64748b")
line(ax, [(750, 220), (880, 220)])
text(ax, 758, 212, "1──∞ source.conversation", 9, "#64748b")
line(ax, [(750, 390), (880, 390)])
text(ax, 758, 382, "1──∞ source.message", 9, "#64748b")
line(ax, [(750, 575), (820, 575), (820, 432), (880, 432)])
text(ax, 826, 508, "0..1──∞ source.task", 9, "#64748b", rotation=-90)
line(ax, [(1155, 450), (1155, 510)])
text(ax, 1166, 484, "1──∞", 9.5, "#64748b")
line(ax, [(880, 428), (845, 428), (845, 770), (880, 770)])
text(ax, 838, 606, "1──1", 9.5, "#64748b", rotation=-90)
line(ax, [(1430, 300), (1472, 300), (1472, 770), (1430, 770)])
text(ax, 1484, 520, "∞──∞ 条目间关系（self）", 9.5, "#64748b", rotation=-90)

# 底部 MemoryContext 条
box(ax, 70, 870, 1360, 60, "#f1f5f9", "#cbd5e1")
ctext(ax, 750, 894, "统一读写上下文 MemoryContext = { operatorId, projectId?, conversationType }", 11.5, "#0f172a", "bold")
ctext(ax, 750, 916, "shared 会话强制屏蔽 personal（守卫①）；存储层再校验 operatorId == owner_id（守卫②）", 10, "#475569")

fig.savefig("memory-system-design/er-model.png", dpi=200, facecolor="#f8fafc")
plt.close(fig)

# ================================================================ 4. write pipeline
fig, ax = make_canvas(1560, 730)

ctext(ax, 780, 30, "写入管道：萃取 → 判重与冲突 → 路由与落库", 19, weight="bold")
ctext(ax, 780, 58, "上排为阶段流；下排三列分别是 ④ 判重规则、⑤ 路由决策表、⑥⑦ 确认与落库动作的展开", 11, "#64748b")

stages = [
    ("① 写入来源", ["会话结束 / 每 8 轮", "“记住…” 显式触发", "手动编辑"], "#eef2ff", "#c7d2fe", "#3730a3"),
    ("② 萃取器 LLM", ["六类模板", "负例清单（防污染）"], "#fffbeb", "#fcd34d", AMBER_T),
    ("③ 候选条目", ["evidenceMessageId", "confidence", "suggestedScope"], "#fffbeb", "#fcd34d", AMBER_T),
    ("④ 判重与冲突", ["向量 sim", "+ 结构化字段比对"], "#f0fdfa", "#5eead4", TEAL_T),
    ("⑤ 路由", ["scope / confidence", "/ 冲突 → 去向"], "#f0fdfa", "#5eead4", TEAL_T),
    ("⑥ Memory Writer", ["事务写入"], "#faf5ff", "#d8b4fe", PURP_T),
    ("⑦ Memory Store", ["revisions · 承继链", "embeddings"], "#f0fdf4", "#86efac", GREEN_T),
]
ys, hh, w, gap, x0 = 180, 96, 180, 25, 75
for i, (t, subs, fc, ec, tc) in enumerate(stages):
    x = x0 + i * (w + gap)
    box(ax, x, ys, w, hh, fc, ec, shadow=True)
    ctext(ax, x + w / 2, ys + 28, t, 12, tc, "bold")
    for j, s in enumerate(subs):
        ctext(ax, x + w / 2, ys + 52 + j * 18, s, 9, "#475569")
    if i < len(stages) - 1:
        arrow(ax, x + w, ys + hh / 2, x + w + gap, ys + hh / 2, mutation=18)

# 展开列
dy, dh, cw = 370, 230, 440
field_box(ax, 80, dy, cw, dh, "#ffffff", "#5eead4", "④ 判重与冲突规则（Rule A–D）", TEAL_T,
          ["Rule A｜结构化冲突：同一 (主体, 字段) 值不同", "　　　　→ 确认卡片（如预算 50 万 vs 80 万）",
           "Rule B｜sim > 0.93 且同类型 → NOOP，", "　　　　evidence 并入旧条目 history",
           "Rule C｜0.85 < sim ≤ 0.93 → LLM 判定：", "　　　　同义→按 B；更新→确认卡片；冲突→按 A",
           "Rule D｜sim ≤ 0.85 → 新条目",
           "特例｜commitment 恒为新条目，仅按 due 设 TTL"],
          field_size=10, line_h=24, shadow=True)
field_box(ax, 560, dy, cw, dh, "#ffffff", "#5eead4", "⑤ 路由决策表", TEAL_T,
          ["personal 且 conf ≥ 0.9 无冲突 → 直接 active", "　　　（项目可配置为仍需确认）",
           "project 且 conf ≥ 0.75 → 确认卡片",
           "有冲突 / 覆盖他人条目 → 确认卡片",
           "conf < 0.75 → candidate（沉淀摘要，", "　　　7 天未确认 → discarded）",
           "显式触发 → 一律确认卡片",
           "写放大：单会话候选上限 20 条"],
          field_size=10, line_h=24, shadow=True)
field_box(ax, 1040, dy, cw, dh, "#ffffff", "#d8b4fe", "⑥⑦ 确认卡片与落库动作", PURP_T,
          ["确认卡片三选项：",
           "　　　保留旧值 / 覆盖（承继链）/ 并存标注分歧",
           "覆盖他人条目 → 通知原作者（进入项目时汇总）",
           "确认通过 → 事务写入：",
           "　　　entry + revision（审计）+ embedding",
           "失败降级：LLM 判定不可用 → 全部走人工确认",
           "污染回退：接受率跌阈 → 回到全确认模式"],
          field_size=10, line_h=24, shadow=True)

# 虚线连接阶段与展开列
for sx, cx in [(780, 300), (985, 780), (1190, 1260)]:
    line(ax, [(sx, ys + hh), (sx, 320), (cx, 320), (cx, dy - 6)], dashed=True, lw=1.4)

ctext(ax, 780, 668, "关键不变式：冲突绝不静默覆盖；候选一律带 evidenceMessageId；所有写操作只经 Memory Writer 单点进入", 10, "#64748b")

fig.savefig("memory-system-design/write-pipeline.png", dpi=200, facecolor="#f8fafc")
plt.close(fig)

print("done")
