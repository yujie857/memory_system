# 销售场景 Agent 记忆系统 · 方案设计（深入版）

> 版本：V0.2 · 适用平台：参考腾讯 WorkBuddy「项目空间 + 成员」形态的 Agent 平台
> 配套图：`architecture.png`（总体架构）、`er-model.png`（实体绑定）、`write-pipeline.png`（写入管道）、`data-partition.png`（数据分区）
> V0.2 相对 V0.1：新增「项目空间模型与记忆绑定」全部细节、SQL 级数据模型、读写管道可实现规格、权限矩阵、事件/通知、自动化 job、容量与灰度计划。

---

## 目录

1. [背景与约束](#1-背景与约束)
2. [项目空间模型与记忆的绑定关系](#2-项目空间模型与记忆的绑定关系)
3. [总体模型：两层作用域 × 六种类型](#3-总体模型)
4. [数据模型（SQL 级）](#4-数据模型sql-级)
5. [写入路径（可实现规格）](#5-写入路径可实现规格)
6. [读取路径（可实现规格）](#6-读取路径可实现规格)
7. [权限矩阵](#7-权限矩阵)
8. [事件、通知与审计](#8-事件通知与审计)
9. [生命周期自动化](#9-生命周期自动化)
10. [容量、时延与规模预算](#10-容量时延与规模预算)
11. [指标与灰度计划](#11-指标与灰度计划)
12. [失败模式与降级](#12-失败模式与降级)
13. [阶段划分](#13-阶段划分)
14. [需平台侧校准的假设](#14-需平台侧校准的假设)
15. [附录：完整交互走查](#15-附录完整交互走查)

---

## 1. 背景与约束

| 项目 | 结论（来自需求对齐） |
|---|---|
| 平台形态 | 用户创建**项目空间**，邀请成员加入（参考腾讯 WorkBuddy 项目模式） |
| 成员 | **真实销售人员**，各自通过 Agent 助手工作；一人可同时活跃于任意多个项目 |
| 记忆分层 | **个人记忆（严格私有）** + **项目记忆（成员间共享）**；不设独立任务记忆层 |
| 写入方式 | 对话**自动萃取** + 用户**显式触发**；需来源溯源、编辑、删除、过期失效 |
| 冲突处理 | 冲突时**由用户确认**，绝不静默覆盖 |
| 组织级知识库 | 暂无，`org` 层为预留扩展 |

---

## 2. 项目空间模型与记忆的绑定关系

记忆系统不独立存在，它的每一次读/写都必须锚定在项目空间的实体上。本节先给出**假设版**的平台模型（待校准项见 §14），剩余所有设计都建立在这个模型上。

### 2.1 项目空间实体模型（假设版）

```
Agent 平台
└── Project（项目空间）
    ├── 基本信息：projectId / 名称 / 客户 / status(active | archived) / createdBy
    ├── Membership：{ userId, role: owner | member, joinedAt }      ← 成员进出事件的来源
    ├── Conversation（会话）：{ conversationId, projectId, type, participants[] }
    │     ├── type = member_private   成员 × 个人助手（每成员可有多个，跟随人）
    │     └── type = shared           项目共享会话（多成员 + Agent，可有多个 topic）
    ├── Task（任务，可选实体）：{ taskId, projectId, assigneeId, status, dueAt }
    └── Artifact（产物，可选）：文件 / 纪要 / 报价单等
```

Agent 形态（假设）：

- **个人助手**：绑定 `userId`，跨项目是同一个助手；人格/偏好由 personal 记忆塑造。
- **项目共享 Agent**：承载 shared 会话，行为上下文只含 project 层。
- 每条消息有稳定的 `messageId`（溯源锚点的硬性需求）。

### 2.2 记忆的绑定维度

| 维度 | personal 记忆 | project 记忆 |
|---|---|---|
| 归属键 | `ownerId = userId` | `projectId` |
| 可见范围 | 仅 owner 本人 | Membership 内全部成员 |
| 跨项目行为 | 跨项目跟随人，以「来源项目标签」做软回溯 | 不跨项目，按 `projectId` 硬隔离 |
| 成员退出 | 不受影响 | **条目保留在项目，不随人走** |
| 项目归档 | 不受影响 | 整体只读 |

每条记忆**必须**携带来源 `source = { kind, conversationId, messageId, taskId? }`，这是溯源、审计、以及后续「按证据回看」的产品能力的数据基础，不可省略。

### 2.3 读写上下文三元组

记忆系统的所有接口都围绕一个上下文三元组定义：

```
MemoryContext = { operatorId, projectId?, conversationType: private | shared }
```

- `operatorId`：当前操作者（用户或代表用户的 Agent），**权限与 personal 可见性的判定根**。
- `projectId`：当前所在项目（个人助手在非项目上下文中可为空）。
- `conversationType`：**注入边界规则的开关**——shared 会话一律屏蔽 personal 记忆（见 §6.3）。

规则一句话版本：**personal 记忆只能出现在 owner 自己的 private 会话上下文里，project 记忆可以出现在该项目所有成员的 private 会话和该项目的 shared 会话里。**

### 2.4 实体关系（记忆系统视角）

```
User 1───∞ memory_entry(scope=personal, owner_id)
Project 1───∞ memory_entry(scope=project, project_id)
Conversation 1───∞ memory_entry.source.conversation_id
Message   1───∞ memory_entry.source.message_id      ← 条目的证据锚点
Task      0..1───∞ memory_entry.source.task_id      ← 任务产生的记忆可追溯
memory_entry ∞──∞ memory_entry (memory_links: derived_from / duplicates / contradicts)
memory_entry 1───∞ memory_revisions                 ← 全部变更历史
```

![项目空间实体 × 记忆系统绑定](er-model.png)

---

## 3. 总体模型

### 3.1 作用域（Scope）

| 作用域 | 归属 | 可见性 | 说明 |
|---|---|---|---|
| `personal` | 单个 member | **仅本人** | 全局一份、跨项目跟随人；以来源项目标签软回溯 |
| `project` | 项目空间 | 项目内全体成员 | 跟随项目走；成员进出不影响 |
| `org`（预留，V3） | 组织 | 全员 | 产品资料、竞品库、标准话术、赢/输单复盘 |

### 3.2 记忆类型（Type）

| 类型 | 内容 | 示例 | 典型作用域 |
|---|---|---|---|
| `fact` 客户事实 | 客户公司、行业、规模、组织架构、决策人及角色 | “李总是技术总监，也是最终决策人；预算 50 万，Q3 立项” | project |
| `need` 需求痛点 | 痛点、采购流程、决策标准、时间表 | “核心诉求是把人工质检成本降 30%” | project |
| `intel` 竞争情报 | 竞对在用什么、优劣势对比 | “在用 X 厂商，抱怨其售后响应慢” | project |
| `episode` 互动记录 | 拜访/会议纪要、异议与应对、口头表态 | “7.2 拜访，客户对部署周期提出异议，已用 XX 案例回应” | project |
| `preference` 偏好 | 客户沟通偏好 / 成员自己的工作习惯 | “王经理只看微信，周五下午方便” | 两者都有 |
| `commitment` 承诺/行动项 | 谁承诺了什么、截止时间 | “我承诺周三前发 POC 报价单” | project（到期/完成即过期） |
| `lesson` 经验沉淀 | 打法、赢/输单原因、个人技巧 | “这类客户先约 C 层再约执行层效率高” | personal + 项目复盘 |

类型与作用域正交；`commitment` 与任务系统通过 `taskId` 互链，记忆系统只记事实与承诺，**不承载任务执行状态**。

### 3.3 为什么不设独立「任务记忆」层

任务多为短期执行单元：独立成层会引入检索路由复杂度、任务结束后记忆失去挂载点、权限模型重复定义三处问题。替代方案：任务上下文萃取后沉淀到项目记忆并标注 `source.taskId`；临时性事项用 `commitment` + TTL 覆盖。

---

## 4. 数据模型（SQL 级）

以 Postgres 为例（`pgvector` 承载向量）。

### 4.1 主表

```sql
CREATE TABLE memory_entries (
  id            TEXT PRIMARY KEY,                    -- mem_<ULID>
  scope         TEXT NOT NULL CHECK (scope IN ('personal','project')),  -- 'org' 预留
  project_id    TEXT,                                -- scope=project 必填（见 CHECK）
  owner_id      TEXT NOT NULL,                       -- scope=personal 的归属人；project 层记入条目作者
  type          TEXT NOT NULL CHECK (type IN
                  ('fact','need','intel','episode','preference','commitment','lesson')),
  text          TEXT NOT NULL,
  structured    JSONB,                               -- 可选结构化字段 {person, role, budget, ...}
  tags          JSONB NOT NULL DEFAULT '[]',         -- string[] 含来源项目标签
  status        TEXT NOT NULL DEFAULT 'candidate' CHECK (status IN
                  ('candidate','active','superseded','expired','archived','deleted','discarded')),
  superseded_by TEXT REFERENCES memory_entries(id),  -- 承继链
  confidence    REAL NOT NULL DEFAULT 1.0,           -- 萃取置信度；手动/显式恒 1
  pinned        BOOLEAN NOT NULL DEFAULT FALSE,
  expires_at    TIMESTAMPTZ,                         -- TTL；commitment 常用
  source        JSONB NOT NULL,                      -- {kind, conversationId, messageId, taskId}
  created_by    TEXT NOT NULL,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK ((scope = 'project') = (project_id IS NOT NULL))
);

CREATE INDEX idx_memory_project_hot
  ON memory_entries (project_id, status, type, updated_at DESC);
CREATE INDEX idx_memory_personal
  ON memory_entries (owner_id, scope, status, updated_at DESC);
CREATE INDEX idx_memory_tags ON memory_entries USING GIN (tags);
CREATE INDEX idx_memory_expiry ON memory_entries (expires_at) WHERE status = 'active';
```

### 4.2 修订与审计

```sql
CREATE TABLE memory_revisions (
  id         BIGSERIAL PRIMARY KEY,
  memory_id  TEXT NOT NULL REFERENCES memory_entries(id),
  actor_id   TEXT NOT NULL,
  actor_kind TEXT NOT NULL CHECK (actor_kind IN ('user','agent','system')),
  action     TEXT NOT NULL CHECK (action IN
    ('created','confirmed','rejected','edited','superseded','expired','archived','deleted','promoted','pinned','unpinned')),
  before     JSONB,
  after      JSONB,
  source     JSONB NOT NULL,                         -- 本次变更的来源会话/消息
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_rev_memory ON memory_revisions (memory_id, created_at);
```

### 4.3 向量与关系

```sql
CREATE TABLE memory_embeddings (
  memory_id  TEXT PRIMARY KEY REFERENCES memory_entries(id) ON DELETE CASCADE,
  project_id TEXT,                  -- 冗余以支持分区/预过滤
  scope      TEXT NOT NULL,
  embedding  vector(1024) NOT NULL
);

CREATE TABLE memory_links (         -- 条目间关系
  from_id TEXT NOT NULL REFERENCES memory_entries(id),
  to_id   TEXT NOT NULL REFERENCES memory_entries(id),
  rel     TEXT NOT NULL CHECK (rel IN ('derived_from','duplicate_of','contradicts')),
  PRIMARY KEY (from_id, to_id, rel)
);
```

要点：

- **承继链用 `superseded_by` 指针**而非覆盖字段，历史可查（revisions 同步记录）。
- **embedding 行可整体重建**：关系库是事实源，向量库是派生索引。
- `expires_at` 用部分索引，过期扫描成本与活跃条目数线性相关而非全表。

---

## 5. 写入路径（可实现规格）

![总体架构](architecture.png)

![写入管道：萃取 → 判重与冲突 → 路由与落库](write-pipeline.png)

### 5.1 触发点

| 触发 | 时机 | 说明 |
|---|---|---|
| 会话结束 | session close 事件 | 主力通道，异步执行 |
| 轮次节流 | 每累计 8 轮对话 | 长会话兜底，避免信息滞留到结束才萃取 |
| 显式指令 | “记住……” 立即 | 同步返回确认卡片 |
| 手动编辑 | 记忆管理界面 | 增/删/改/置顶/过期/升格 |
| 项目归档 | status 变更事件 | 触发复盘萃取（§9.3） |

### 5.2 萃取器 I/O 契约

输入：

```
{
  "conversation": [ {messageId, role, authorId, text, ts} ],   // 本会话新增片段
  "existingMemories": [ {id, type, text, structured} ],        // 检索召回的近似旧条目（供判重，≤20 条）
  "context": { operatorId, projectId, conversationType, projectMeta }
}
```

输出（JSON，逐类型的六套模板之一）：

```
{
  "candidates": [
    {
      "type": "fact",
      "text": "李总是技术总监，也是最终决策人，预算约 50 万",
      "structured": { "person": "李总", "role": "decision_maker", "budget": 500000 },
      "suggestedScope": "project",
      "tags": ["某制造集团", "预算"],
      "evidenceMessageId": "msg_…",        // 必填：证据锚点
      "confidence": 0.92,
      "expiresAt": null                    // commitment 可填 due
    }
  ]
}
```

萃取负例（写进 Prompt，防污染）：寒暄闲聊、一次性情绪、口头玩笑、与项目无关的个人琐事（除非用户显式说记住）、CRM 已结构化的字段（若对接）。

### 5.3 去重 / 冲突检测算法

对每条候选，与同 scope 的 active 条目做两级判定：

```
sim = cosine(candidate.embedding, existing.embedding)

Rule A  结构化冲突: 同一 (主体, 字段) 值不同（如 budget 50万 vs 80万）
        → 冲突 → 确认卡片（保留旧值 / 覆盖 / 并存）
Rule B  sim > 0.93 且 type 相同
        → 重复：NOOP，仅把新 evidenceMessageId 追加进旧条目 history
Rule C  0.85 < sim ≤ 0.93
        → LLM 判定「同义 / 更新 / 冲突 / 无关」：
            同义→按 B；更新→生成 supersede 提案；冲突→按 A；无关→新条目
Rule D  sim ≤ 0.85 → 新条目
特殊    commitment 一律新条目（承诺天然多条），仅按 due 做 TTL
```

### 5.4 路由决策表

| 条件 | 去向 |
|---|---|
| scope=personal 且 confidence ≥ 0.9 且无冲突 | 直接 active（可配置为仍需确认） |
| scope=project 且 confidence ≥ 0.75 且无冲突 | 确认卡片（共享层默认多一道人闸） |
| 有冲突 | 确认卡片（冲突三选项） |
| confidence < 0.75 且无冲突 | 静默 candidate，并入**会话末尾沉淀摘要** |
| 显式指令产生 | 一律回显确认卡片再写入 |

**写放大控制**：单会话候选上限 20 条；被 Rule B 命中的追加不产生新卡片。

### 5.5 确认卡片与沉淀摘要（UX）

- **确认卡片**（会话内）：展示条目草稿（类型/作用域/正文/结构化字段）+ 冲突对象的旧值对比；操作：确认 / 编辑 / 丢弃 / 改为 personal。
- **沉淀摘要**（会话末尾）：「本次会话沉淀 3 条：① …… ② …… ③ ……」，每条提供「保留 / 编辑 / 丢弃」。无操作默认 7 天后丢弃。
- V1 若 UI 排期紧张：沉淀摘要可先落在会话末尾一条消息，点击跳转记忆管理页。

---

## 6. 读取路径（可实现规格）

### 6.1 三种读取时机

| 时机 | 通道 | 预算 |
|---|---|---|
| ① 会话启动注入 | 上下文组装器（§6.2） | ≤ 600 token |
| ② 按需检索 | `memory_search` 工具（§6.4） | 每次 ≤ topK 条 |
| ③ 事件提醒（V2） | 通知中心 + 会话内提醒 | — |

### 6.2 会话启动注入算法

```
assemble(ctx: MemoryContext, currentMessage?):
  scopes = 6.3 守卫后的 scope 白名单
  parts = []
  1) pinned: status=active AND pinned, 按 updated_at 倒序
  2) recent: status=active AND type ∈ {fact, need, intel} AND updated_at > now-14d, 每 scope ≤ 10
  3) openCommitments: type=commitment AND active AND expires_at > now, 按 expires_at 升序
  4) topical: embed(currentMessage) → 向量 topK=3（sim ≥ 0.78），与 1-3 去重
  5) 预算执行：超 600 token 时依次裁 4 → 合并 2 → LLM 摘要压缩 1+2
  6) 渲染：按 personal / project 分组，条目格式：
     "· [A · 9/2 · fact] 李总是最终决策人，预算约 50 万 (#mem_01J)"
```

注入模板（系统消息片段）示例：

```
## 项目记忆（某制造集团 · 成员共享）
· [A · 9/2 · fact] 李总是技术总监，也是最终决策人；预算约 50 万，Q3 立项 (#mem_01J)
· [B · 9/4 · episode] 9.3 拜访：客户担忧部署周期，已用华东案例回应 (#mem_02K)
· [A · 9/4 · commitment] A 承诺 9/10 前发 POC 报价单 (#mem_03L)
## 我的记忆（仅你可见）
· [A · 8/28 · preference] 该客户汇报要结论先行、三段式 (#mem_07P)
```

### 6.3 注入边界守卫（防泄露双保险）

1. **组装器层**：`conversationType = shared` 时，scope 白名单强制为 `{project}`——personal 连召回请求都不会发出；
2. **存储层**：Retriever 校验 `personal` 条目必须满足 `operatorId == owner_id`，否则记录安全告警并拒绝。

两层独立实现，任一层失守都不造成泄露。

### 6.4 `memory_search` 工具签名

```json
{
  "name": "memory_search",
  "description": "检索当前操作者可见的记忆（个人 + 当前项目）。返回带作者、时间与来源。",
  "parameters": {
    "query": "string，必填",
    "scope": ["personal", "project"],
    "type": ["fact", "need", "intel", "episode", "preference", "commitment", "lesson"],
    "tags": ["string"],
    "since": "ISO8601", "until": "ISO8601",
    "topK": 8,
    "includeHistory": false
  },
  "returns": [{
    "id": "mem_…", "scope": "…", "type": "…",
    "text": "…", "structured": {}, "tags": [],
    "authorId": "…", "updatedAt": "…",
    "source": { "conversationId": "…", "messageId": "…" },
    "status": "active"
  }]
}
```

辅助工具（V1 同步提供）：`memory_remember(text, scope, type, tags[])`（显式写入，走 §5.5 回显确认）、`memory_pin(id, pinned)`、`memory_correct(id, newText)`（自我修正，走 supersede 流程）。

---

## 7. 权限矩阵

| 操作 | personal（owner） | personal（他人，含管理员） | project（作者本人） | project（项目 owner/管理员） | project（其他成员） |
|---|---|---|---|---|---|
| 读 | ✔ | ✘ | ✔ | ✔ | ✔ |
| 新增 | ✔ | ✘ | ✔ | ✔ | ✔ |
| 编辑/删除 | ✔ | ✘ | ✔（自己的条目） | ✔ | ✘ |
| 覆盖他人条目（冲突确认后） | — | — | 需确认 + 通知作者 | 需确认 + 通知作者 | 需确认 + 通知作者 |
| 置顶 / 升格 personal→project | ✔ | — | ✔ | ✔ | 需管理员审核（可配置） |
| 归档后任何写操作 | — | — | ✘（只读） | ✘ | ✘ |

- personal 的隔离在存储层硬过滤实现，而非提示词约束。
- 项目管理员不可见成员的 personal，「管理员能看到一切」不成立。

---

## 8. 事件、通知与审计

### 8.1 域事件

| 事件 | 触发 | 通知对象 |
|---|---|---|
| `MemoryProposed` | 产生 candidate（含冲突） | 写入者（确认卡片） |
| `MemoryAdded` | 条目 active | 无（避免噪音） |
| `MemorySuperseded` | 旧条目被覆盖 | 旧条目作者（进入项目时一次性汇总） |
| `MemoryPromoted` | personal→project | 项目成员（项目动态流） |
| `CommitmentDueSoon` | due 前 24h | 承诺人 |
| `MemoryExpiringSoon` | TTL 到期前 | 条目作者（“还有效吗？”续期卡片） |
| `ProjectArchived` | 项目归档 | 复盘萃取产物发送给项目 owner |

通知复用平台消息中心；同类事件在「进入项目时」聚合为一条汇总，避免逐条打扰。

### 8.2 审计查询

按 `memory_id` 拉取 `memory_revisions` 全链；管理界面的「修改历史」直接渲染该链（谁、何时、改了什么、来源会话）。

---

## 9. 生命周期自动化

### 9.1 周期 job

| Job | 频率 | 动作 |
|---|---|---|
| commitment 提醒 | 每 15 min | `expires_at - now ≤ 24h` 发 `CommitmentDueSoon` |
| TTL 过期 | 每日 | 到期 → 发续期确认；7 天未确认 → `expired` |
| 候选清理 | 每日 | candidate 超 7 天未确认 → `discarded` |

### 9.2 成员进出事件

- **加入**：生成「项目记忆导览」（置顶 + 活跃事实 + 未结 commitment 的压缩摘要）推送给新成员，降低上手成本。
- **退出**：其 project 条目保留；personal 不受影响；未确认 candidate 一并清理。

### 9.3 项目归档

`status → archived` 触发：

1. 全部 project 条目转 `archived`（只读可查）；
2. 启动**复盘萃取**：输入全部 episode/commitment + 项目结果（赢/输），产出 `lesson` 候选 → 项目 owner 确认后成立；
3. owner 个人的 lesson 可保留在其 personal 层（跨项目跟随）。

---

## 10. 容量、时延与规模预算

按平台中期规模估算（可调）：

| 维度 | 假设 | 推算 |
|---|---|---|
| 项目数 | 500 活跃 | — |
| 每项目成员 | 3–8 | — |
| 每项目活跃记忆 | 200–2000 条 | 全平台 10⁵–10⁶ 条，关系库存储 < 5 GB |
| 单条体量 | 0.5–2 KB + 1024 维向量 | 向量索引 < 8 GB，单机 pgvector 可承载 |
| 会话启动注入 | 检索 p95 < 200 ms | 走索引预过滤 + 小 topK |
| 自动萃取 | 异步，会话结束后 ≤ 60 s 完成 | 不阻塞会话 |
| 每会话萃取成本 | 输入 ~4k token + 输出 ~1k token | 按日活会话数线性，可控 |

---

## 11. 指标与灰度计划

### 11.1 关键指标

| 指标 | 目标 | 用途 |
|---|---|---|
| 萃取接受率 | ≥ 70% | 低于目标说明萃取噪音大，调 Prompt/阈值 |
| 冲突率 | 监控 | 反映多成员记录的口径分歧程度 |
| 重复率（Rule B 占比） | 监控 | 衡量萃取与判重的平衡 |
| 检索引用率 | topK 命中率 | 注入/检索质量；驱动阈值与 rerank 调优 |
| 沉淀摘要打开/操作率 | 监控 | 确认 UX 是否打扰过度 |

### 11.2 灰度

1. 内部试点 2–3 个项目，只开 personal 层 + 显式触发；
2. 开 project 层自动萃取（全部走确认卡片）；
3. 接受率达标后放开高置信度直写 personal；最后全量推广。

---

## 12. 失败模式与降级

| 失败 | 处置 |
|---|---|
| 萃取 LLM 调用失败 | 重试 3 次后放弃本轮，会话不受影响；事件记入指标 |
| LLM 冲突判定不可用 | 退化为「全部走人工确认卡片」 |
| 向量索引损坏 | 降级为 BM25 检索；后台从关系库重建 embedding |
| 记忆膨胀（项目超 2000 条） | 触发压缩任务：合并同义、归档低引用的旧 episode |
| 萃取污染被投诉 | 管理页支持按会话/时间批量清理候选；接受率跌出阈值自动回退到全确认模式 |

---

## 13. 阶段划分

| 阶段 | 内容 |
|---|---|
| **V1** | 两层 scope、六类型、§4 全表结构；萃取（默认全确认）+ 显式触发 + 手动管理；§6.2 启动注入 + `memory_search` / `memory_remember` / `memory_correct` / `memory_pin`；权限矩阵；revisions 审计 |
| **V2** | §8 事件通知全套；§9 自动化 job；成员加入导览；项目归档复盘；共享会话双保险的执行演练 |
| **V3** | `org` 层；跨项目个人模式洞察；记忆质量分析驱动萃取调优 |

---

## 14. 需平台侧校准的假设

以下假设直接决定接口与表结构，若有出入请告知，方案按真实模型修订：

1. **角色模型**：项目空间是否有 owner/管理员角色？（影响 §7 权限矩阵默认值）
2. **共享会话**：项目空间内是否存在多成员共享会话？（决定 §6.3 守卫是否在 V1 就要）
3. **消息锚点**：会话消息是否有稳定的 `messageId` 且可回链？（溯源依赖）
4. **任务系统**：平台内是否已有 Task 实体与 `taskId`？（commitment 互链与萃取来源标注）
5. **通知通道**：是否已有消息中心/通知能力可复用？（§8 全套依赖）
6. **CRM**：是否已有 CRM 及需要同步的字段口径？（结构化字段与萃取负例依赖）

---

## 15. 附录：完整交互走查

**场景**：成员 A 与同事 B 共同跟进客户「某制造集团」，项目已有 B 写入的预算记忆“80 万”。

1. **萃取**：A 的会话中获知“预算 50 万”→ 萃取器产出 `fact` 候选（scope=project，evidence=msg_x，confidence=0.92）。
2. **冲突检测**：Rule A 命中（budget 字段值不同）→ A 收到确认卡片，展示新旧值对比与来源对话链接。
3. **确认**：A 选「覆盖」→ 新条目 active，旧条目 `superseded` 挂承继链，revisions 记录双重来源；B 进入项目时收到「你的预算记录已被 A 更新为 50 万（来源 9/5 会话）」。
4. **启动注入**：A 次日开会话，组装器注入活跃事实与未结 commitment；B 的会话同样拿到（project 层共享）。
5. **按需检索**：助手被问“客户采购流程走几步？”时调用 `memory_search`，命中 `need` 条目并给出来源消息链接。
6. **个人层**：A 说“记住，这家的汇报用他们生产例会时间发”→ personal `preference`，仅 A 可见，不进入 B 的任何上下文。
7. **升格**：A 将“先约 C 层再约执行层”的打法升格为 `lesson` 投稿 → 项目动态流通知成员。
8. **闭环**：commitment「9/10 前发 POC 报价单」到期前 24h 提醒 A；项目赢单归档后触发复盘萃取，产出 lesson 候选由项目 owner 确认沉淀。
